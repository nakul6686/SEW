import React, { useState } from "react";
import {
  Box,
  Card,
  CardActions,
  CardContent,
  Button,
  Typography,
  Stack,
  ButtonGroup,
} from "@mui/material";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

import DownloadIcon from "@mui/icons-material/Download";
import AddAlertIcon from "@mui/icons-material/AddAlert";
import RecyclingIcon from "@mui/icons-material/Recycling";

const TopBottomBorderBar = (props) => {
  const { x, y, width, height } = props;
  const borderWidth = 1; // Adjust the width of the border as needed

  return (
    <g>
      {/* Bottom border */}
      <rect
        x={x}
        y={y + height - borderWidth}
        width={width}
        height={borderWidth}
        fill="white"
      />
      {/* Top border */}
      <rect x={x} y={y} width={width} height={borderWidth} fill="white" />
      {/* Main body of the bar */}
      <rect
        x={x}
        y={y + borderWidth}
        width={width}
        height={height - 2 * borderWidth}
        fill="blue"
      />
    </g>
  );
};
const bull = (
  <Box
    component="span"
    sx={{ display: "inline-block", mx: "2px", transform: "scale(0.8)" }}
  >
    •
  </Box>
);
function ChartCard() {
  const [chartData, setChartData] = useState([
    {
      name: "Jan 19",
      super: 200,
      on: 100,
      off: 50,
    },
    {
      name: "Feb",
      super: 120,
      on: 90,
      off: 49,
    },
    {
      name: "Mar",
      super: 115,
      on: 140,
      off: 88,
    },
    {
      name: "Apr",
      super: 150,
      on: 123,
      off: 50,
    },
    {
      name: "May",
      super: 180,
      on: 90,
      off: 99,
    },
    {
      name: "Jun",
      super: 170,
      on: 70,
      off: 65,
    },
    {
      name: "Jul",
      super: 250,
      on: 50,
      off: 50,
    },
    {
      name: "Aug",
      super: 120,
      on: 120,
      off: 80,
    },
    {
      name: "Sep",
      super: 173,
      on: 127,
      off: 53,
    },
    {
      name: "Oct",
      super: 32,
      on: 91,
      off: 123,
    },
    {
      name: "Nov",
      super: 150,
      on: 101,
      off: 67,
    },
    {
      name: "Dec",
      super: 99,
      on: 99,
      off: 100,
    },
    {
      name: "Jan 20",
      super: 56,
      on: 76,
      off: 92,
    },
  ]);

  
  return (
    <Card sx={{ minWidth: 275 }}>
      <CardContent className="custom-card-content">
        <div className="card-inner">
          <div className="top-actions">
            <ButtonGroup
              ize="small" aria-label="small button group"
            >
              <Button className="active">Dollar</Button>
              <Button>Uasage</Button>
            </ButtonGroup>
          </div>
          <ResponsiveContainer width="100%" height={400}>
            <BarChart
              data={chartData}
              margin={{
                top: 20,
                right: 30,
                left: 20,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="" vertical={false} />
              <XAxis dataKey="name" />
              <YAxis axisLine={false} />
              {/* <Tooltip /> */}
              <Legend />
              <Bar
                dataKey="super"
                stackId="a"
                fill="#2e5299"
                barSize={30}
                name="Super Off Peaak"
              />
              <Bar
                dataKey="off"
                stackId="a"
                fill="#215ed9"
                barSize={30}
                shape={<TopBottomBorderBar />}
                name="Off Peak"
              />
              <Bar
                dataKey="on"
                stackId="a"
                fill="#85baef"
                barSize={30}
                name="On Peak"
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
      <CardActions className="action-btns">
        <Stack direction="row" spacing={2}>
          <Button startIcon={<DownloadIcon />}>Download Excel</Button>
          <Button startIcon={<RecyclingIcon />}>Green Button</Button>
          <Button startIcon={<AddAlertIcon />}>Manage Usage Alerts</Button>
        </Stack>
      </CardActions>
    </Card>
  );
}

export default ChartCard;
