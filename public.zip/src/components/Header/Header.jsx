import React from "react";
import {
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Menu,
  MenuItem,
  Container,
  Button,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import AccountCircle from "@mui/icons-material/AccountCircle";
import NotificationsIcon from "@mui/icons-material/Notifications";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import HelpIcon from "@mui/icons-material/Help";

import "./header.css";
function Header() {
  const [anchorEl, setAnchorEl] = React.useState(null);

  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const [billingAnchorEl, setBillingAnchorEl] = React.useState(null);
  const [usageAnchorEl, setUsageAnchorEl] = React.useState(null);

  const handleBillingMenuClick = (event) => {
    setBillingAnchorEl(event.currentTarget);
  };

  const handleUsageMenuClick = (event) => {
    setUsageAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setBillingAnchorEl(null);
    setUsageAnchorEl(null);
  };

  return (
    <>
      <AppBar
        position="static"
        className="custom-AppBar"
        sx={{
          backgroundColor: "#ffffff",
        }}
      >
        <Container maxWidth="md">
          <Toolbar>
            {/* Left Logo */}
            <img
              className="Logo-Img"
              srcSet={`https://www.sew.ai/themes/custom/sewtheme/images/logo2.png`}
              src={`https://www.sew.ai/themes/custom/sewtheme/images/logo2.png`}
              alt={"Logo Image"}
              loading="lazy"
              width={80}
            />

            {/* Right Icons - Profile and Notifications */}
            <div className="custom-right">
              <IconButton
                color="inherit"
                aria-label="notifications"
                sx={{ mr: 2 }}
              >
                <NotificationsIcon />
              </IconButton>

              <IconButton
                size="large"
                edge="end"
                color="inherit"
                aria-label="account of current user"
                aria-controls="menu-appbar"
                aria-haspopup="true"
                onClick={handleMenu}
                sx={{ ml: 2 }}
              >
                <AccountCircle />
              </IconButton>
              {/* Profile Dropdown */}
              <Menu
                id="menu-appbar"
                anchorEl={anchorEl}
                anchorOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                keepMounted
                transformOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                open={Boolean(anchorEl)}
                onClose={handleClose}
              >
                <MenuItem onClick={handleClose}>Profile</MenuItem>
                <MenuItem onClick={handleClose}>My account</MenuItem>
              </Menu>
            </div>
          </Toolbar>
        </Container>
      </AppBar>
      <AppBar  position="static"
        sx={{
          backgroundColor: "#ffffff",
        }}>
        <Container maxWidth="md">
          <Toolbar>
            {/* Left Links */}
            <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
              <Button xs={{
                color: "#000000",
                backgroundColor: "transparent",
                padding: "6px 0 ",
                width: "50px"
              }}>Home</Button>
              <Button xs={{
                color: "#000000",
                backgroundColor: "transparent"
              }} onClick={handleBillingMenuClick}>
                Billing <ArrowDropDownIcon />
              </Button>
              {/* Billing Dropdown */}
              <Menu
                anchorEl={billingAnchorEl}
                open={Boolean(billingAnchorEl)}
                onClose={handleMenuClose}
              >
                <MenuItem onClick={handleMenuClose}>Option 1</MenuItem>
                <MenuItem onClick={handleMenuClose}>Option 2</MenuItem>
              </Menu>

              <Button xs={{
                color: "#000000",
                backgroundColor: "transparent"
              }} onClick={handleUsageMenuClick}>
                Usage <ArrowDropDownIcon />
              </Button>
              {/* Usage Dropdown */}
              <Menu
                anchorEl={usageAnchorEl}
                open={Boolean(usageAnchorEl)}
                onClose={handleMenuClose}
              >
                <MenuItem onClick={handleMenuClose}>Option 1</MenuItem>
                <MenuItem onClick={handleMenuClose}>Option 2</MenuItem>
              </Menu>
            </Typography>

            {/* Right Help Icon */}
            <Typography color={"#000000"} cursor="pointer">
            <IconButton color={"#000000"}>
              <HelpIcon />
            </IconButton> Help
            </Typography>
          </Toolbar>
        </Container>
      </AppBar>
      <AppBar position="static"
        sx={{
          backgroundColor: "#ffffff",
          boxShadow: '0 4px 4px -4px #9a9a9a !important',
        }}>
          <Container maxWidth="md">
            <Typography variant="h5" 
            padding={"10px 0"}
            paddingLeft={"24px"}
            paddingRight={"24px"}
            color={"#000000"}
            >Welcome Jhon,</Typography>
          </Container>

        </AppBar>
    </>
  );
}

export default Header;
