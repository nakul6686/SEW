import React, { useState } from "react";

import {
  Typography,
  Button,
  Grid,
  Card,
  CardActions,
  CardContent,
} from "@mui/material";
import NotificationsIcon from "@mui/icons-material/Notifications";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

function CardComp() {
  const [chartData, setChartData] = useState([
    {
      name: "$16",
      uv: 16,
      amt: 16,
      color: "#52ab88",
      label: "Current Savings",
    },
    {
      name: "$88",
      uv: 88,
      amt: 88,
      color: "#c1e1d5",
      label: "Potential Annual Savings",
    },
  ]);

  const ColoredBar = (props) => {
    const { x, y, width, height, color } = props;
    return (
      <g>
        <rect x={x} y={y} width={width} height={height} fill={color} r={5} />
        {/* Retain bottom horizontal line */}
      </g>
    );
  };

  const CustomTick = (props) => {
    const { x, y, payload } = props;
    console.log(props);
    return (
      <g transform={`translate(${x},${y})`}>
        <foreignObject x={-50} width={100} height={100}>
          <div
            xmlns="http://www.w3.org/1999/xhtml"
            style={{ textAlign: "center" }}
          >
            <Typography>
              <Typography>{payload.value}</Typography>
              <Typography>{payload.label}</Typography>
            </Typography>
          </div>
        </foreignObject>
      </g>
    );
  };
  return (
    <Card>
      <Grid container className="outer-grid">
        <CardContent>
          <Grid item xs={12} sm={12} md={7}>
            <Typography variant="h5" gutterBottom className="card-title">
              CONGRATULATIONS, JOE
            </Typography>
            <Typography variant="body1">
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry. Lorem Ipsum has been the industry's standard dummy text
              ever since the 1500s, and scrambled it to make a type specimen
              book.
            </Typography>
            <CardActions
              className="px-0"
              style={{ padding: "8px 0", marginTop: "15px" }}
            >
              <Button variant="contained" style={{ background: "#215ed9" }}>
                <NotificationsIcon />
                TURN EVENT REMINDERS ON
              </Button>
            </CardActions>
          </Grid>
          <Grid item xs={12} sm={12} md={5}>
            <ResponsiveContainer width="100%" height={150}>
              <BarChart
                data={chartData}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid
                  strokeDasharray="3 3"
                  horizontal={false}
                  vertical={false}
                />
                <XAxis
                  dataKey="name"
                  axisLine={{ stroke: "#dedede" }}
                  tick={<CustomTick />}
                />
                <YAxis axisLine={false} tick={false} />
                <Bar dataKey="uv" shape={<ColoredBar />} barSize={60} />
              </BarChart>
            </ResponsiveContainer>
          </Grid>
        </CardContent>
      </Grid>
    </Card>
  );
}

export default CardComp;
