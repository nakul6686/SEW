import * as React from "react";
import Container from "@mui/material/Container";
import Typography from "@mui/material/Typography";
import { Box } from "@mui/material";

import("./footer.css");
const Footer = () => {
  return (
    <Box
      sx={{
        backgroundColor: "#f5f5f5",
        marginTop: "30px"
      }}
      component="footer"
    >
      <Container maxWidth="md">
        <Typography
          className="privicy-text mb-2"
          variant="body2"
          color="text.secondary"
          align="center"
        >
          <span>Privacy Policy</span> <span>Policy Notice</span>{" "}
          <span>Terms and Conditions</span>
        </Typography>
        <Typography
          className="privicy-text"
          color="text.secondary"
          align="center"
        >
          Utility Co.® registered trademarks of Utility Co.
        </Typography>
        <Typography
          className="privicy-text"
          color="text.secondary"
          align="center"
        >
          © 1998-2019 Utility Co.Ⓡ. The trademarks used herein are the property
          of their respective owners. All rights reserved.
        </Typography>
      </Container>
    </Box>
  );
};

export default Footer;
