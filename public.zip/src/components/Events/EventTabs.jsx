import React, { useState } from "react";
import PropTypes from "prop-types";
import {
  Grid,
  Box,
  Typography,
  Tab,
  Tabs,
  CardContent,
  Card,
  CardMedia,
  CardHeader,
  List,
  ListItem,
  ListItemText,
  ListItemButton,
  ListItemIcon,
  Button,
} from "@mui/material";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import Chip from "@mui/material/Chip";
import Stack from "@mui/material/Stack";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import("./event.css");

function CustomTabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

CustomTabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function extractProps(index) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}

function EventTabs() {
  const [value, setValue] = React.useState(0);
  const [questions, setQuestions] = useState([
    "Will Online Automatic Payments Pay My Current Account",
    "Mauris Mollis Erat Urna, Sit Amet Luctus Erat Scelerisque ld?",
    "Phasellus Dapibus Justo Ut Lectu  Mollis, Eget Venenatis?",
    "Laudem Et Voluptatem?",
  ]);
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <Box sx={{ width: "100%", marginTop: "15px" }}>
      <Box sx={{ borderBottom: "none" }}>
        <Tabs
          value={value}
          onChange={handleChange}
          aria-label="basic tabs example"
        >
          <Tab
            label="MY EVENTS"
            {...extractProps(0)}
            sx={{ padding: "5px 15px !important", minHeight: "38px" }}
          />
          <Tab
            label="PAST EVENTS"
            {...extractProps(1)}
            sx={{ padding: "5px 15px !important", minHeight: "38px" }}
          />
        </Tabs>
      </Box>

      <CustomTabPanel value={value} index={0} classname="tabpannel">
        <Grid container spacing={2}>
          <Grid item xs={12} sm={12} md={12}>
            <Typography
              gutterBottom
              className="card-title"
              style={{ marginTop: "15px" }}
            >
              Upcoming Events
            </Typography>
          </Grid>
          <Grid item xs={12} sm={12} md={8}>
            <Card className="card-margin-right">
              <CardContent xs={{ padding: "0 !important" }}>
                <Grid container>
                  <Grid
                    item
                    xs={12}
                    sm={12}
                    md={2}
                    sx={{
                      borderRight: "1px solid #dedede",
                      padding: "16px 16px",
                    }}
                  >
                    <Typography className="event-left">
                      <Typography className="event-month" variant="h6">
                        MAR
                      </Typography>
                      <Typography className="event-day" variant="h4">
                        7
                      </Typography>
                    </Typography>
                  </Grid>
                  <Grid
                    item
                    xs={12}
                    sm={12}
                    md={7}
                    sx={{ padding: "16px 16px" }}
                  >
                    <Typography variant="h6" fontWeight="bold">
                      AC Saver (SUMMER SAVER)
                    </Typography>

                    <Typography fontWeight="bold" sx={{ marginBottom: "10px" }}>
                      Seasonal | Expected Duration:6 months
                    </Typography>
                    <Typography>
                      We install an AC Saver device on your air conditioning
                      unit. When conservation is needed, we activate the device
                      to cycle your air.
                    </Typography>
                  </Grid>
                  <Grid
                    item
                    xs={12}
                    sm={12}
                    md={3}
                    sx={{ padding: "16px 10px" }}
                  >
                    <Typography>Est. Savings</Typography>
                    <Typography variant="h6" color="#000000" fontWeight={600}>$3.95</Typography>
                    <Stack direction="row" spacing={1}>
                      <Chip
                        icon={<CheckCircleIcon />}
                        label="Enrolled"
                        color="primary"
                      />
                    </Stack>
                  </Grid>
                </Grid>
              </CardContent>
            </Card>

            <Grid item xs={12} sm={12} md={8}>
              <Typography
                gutterBottom
                className="card-title"
                style={{ marginTop: "15px" }}
              >
                PAST Events
              </Typography>
            </Grid>
            <Card className="card-margin-right">
              <CardContent xs={{ padding: "0 !important" }}>
                <Grid container>
                  <Grid
                    item
                    xs={12}
                    sm={12}
                    md={2}
                    sx={{
                      borderRight: "1px solid #dedede",
                      padding: "16px 16px",
                    }}
                  >
                    <Typography className="event-left">
                      <Typography className="event-month" variant="h6">
                        MAR
                      </Typography>
                      <Typography className="event-day" variant="h4">
                        7
                      </Typography>
                    </Typography>
                  </Grid>
                  <Grid
                    item
                    xs={12}
                    sm={12}
                    md={7}
                    sx={{ padding: "16px 16px" }}
                  >
                    <Typography variant="h6" fontWeight="bold">
                      BASE INTERRUPTIBLE PROGRAM
                    </Typography>

                    <Typography fontWeight="bold" sx={{ marginBottom: "10px" }}>
                      2:00PM | Duration: 30 minutes
                    </Typography>
                    <Typography>
                      Lobortis commodo porta vitae class dapibus nibh, cursus
                      cubilia torquent montes eleifend per tortor, aptent dolor
                      ligula eu quam.
                    </Typography>
                  </Grid>
                  <Grid
                    item
                    xs={12}
                    sm={12}
                    md={3}
                    sx={{ padding: "16px 10px" }}
                  >
                    <Typography>You Saved</Typography>
                    <Typography variant="h6" color="#000000" fontWeight={600}>$2.37</Typography>
                    {/* <Stack direction="row" spacing={1}>
                      <Chip icon={<CheckCircleIcon />} label="Enrolled" color="primary"/>
                      
                    </Stack> */}
                  </Grid>
                </Grid>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={12} md={4}>
            <Card sx={{ maxWidth: 345 }} className="custom-card-contentn">
              <CardHeader title="How can we help?" />
              <CardMedia
                component="img"
                height="150"
                image="https://picsum.photos/200"
                alt="Paella dish"
              />
              <CardContent style={{ padding: 0 }}>
                <List disablePaddings>
                  {questions.map((question, index) => (
                    <ListItem style={{ padding: 0 }} key={index}>
                      <ListItemButton>
                        <ListItemText
                          primary={question}
                          style={{ color: "#0000008a" }}
                        />
                        <ListItemIcon>
                          <ChevronRightIcon />
                        </ListItemIcon>
                      </ListItemButton>
                    </ListItem>
                  ))}
                </List>
                <div
                  className="card-footer"
                  style={{ textAlign: "center", marginBottom: "20px" }}
                >
                  <Button href="#" className="vieewmore-button">
                    VIEW MORE FAQS
                  </Button>
                </div>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </CustomTabPanel>
      <CustomTabPanel value={value} index={1}>
        <Typography>Past Events content goes here</Typography>
      </CustomTabPanel>
    </Box>
  );
}

export default EventTabs;
