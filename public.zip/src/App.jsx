import { useState } from "react";
import "./App.css";
import Header from "./components/Header/Header";
import Footer from "./components/footer/Footer";
import { Container, Grid } from "@mui/material";
import CardComp from "./components/card/Card";
import EventTabs from "./components/Events/EventTabs";
import ChartCard from "./components/ChartCard/ChartCard";

function App() {
  const [count, setCount] = useState(0);

  return (
    <>
      <Header />
      <Container maxWidth="md" className="main-content">
        {/* // welcome section */}
        <CardComp />

        {/* Tabs Section */}
        <Grid container style={{marginTop: "20px"}} className="custom-card">
          <Grid item xs={12}>
            <ChartCard />
          </Grid>
        </Grid>

        <EventTabs />
      </Container>

      <Footer />
    </>
  );
}

export default App;
